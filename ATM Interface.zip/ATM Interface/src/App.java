
public class App {
    public static void main(String[] args) throws Exception {
        ATM obj=new ATM();
        obj.checkpin();
    }
}

